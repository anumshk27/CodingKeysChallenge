//
//  HitsEndPoint.swift
//  Pixabay
//
//  Created by Muhammad Anum on 31/03/2022.
//


import Foundation

protocol EndPointType {
    
    var baseURL: URL { get }
    var httpMethod: HTTPMethod { get }
    var task: HTTPTask { get }
    var headers: HTTPHeaders? { get }
}

enum EndPointPath: String {
    
    case username = "<username>"
}

public enum HitsApi {
    
    case request
    case getUserLists(page:Int)
    case getProfileByName(name:String)
}

extension HitsApi: EndPointType {
    
    var baseURL: URL {
        guard let url = URL(string: "https://api.github.com/users") else { fatalError("baseURL could not be configured.")}
        return url
    }
    
    var httpMethod: HTTPMethod {
        return .get
    }
    
    var task: HTTPTask {
        switch self {
        case .getUserLists(let page):
            return .requestParameters(bodyParameters: nil,
                                      bodyEncoding: .urlEncoding,
                                      urlParameters: ["since":page])
            
        case .getProfileByName(let name):
            return .requestParameters(bodyParameters: nil,
                                      bodyEncoding: .urlEncoding,
                                      urlParameters: ["path":name])

        default:
            return .request
        }
    }
    
    var headers: HTTPHeaders? {
        return nil
    }
}


